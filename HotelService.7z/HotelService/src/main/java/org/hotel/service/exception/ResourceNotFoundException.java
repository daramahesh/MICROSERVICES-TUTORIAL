package org.hotel.service.exception;

public class ResourceNotFoundException extends RuntimeException {
    public ResourceNotFoundException(String s) {
    }

    public ResourceNotFoundException() {
    }
}
